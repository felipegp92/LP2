﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;
using System.Net.Http.Headers;
using System.Runtime.Serialization;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            //string saida = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1}º número","Entrada de Dados");  //interaction para usar a biblioteca do visual basic

                if (auxiliar == "")
                {
                    break;
                }
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;//retorne uma casa
                }
                /*else
                {
                    saida = auxiliar + "\n" + saida;
                }*/
            }

            Array.Reverse(vetor); //inverter
            auxiliar = "";
            foreach (int i in vetor)
            {
                auxiliar += i + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            ArrayList alunos = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", 
                                                "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            alunos.Remove("Otávio");
            
            foreach(string s in alunos)
            {
                auxiliar += s + "\n";                
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            Double[,] notas = new Double[20, 3];
            string auxnotas;
            double soma = 0, media = 0;

            for (int i = 0; i < 20; i++) // i = alunos
            {
                for (int j = 0; j < 3; j++) // j = notas
                {
                    auxnotas = Interaction.InputBox($"Digite a {j + 1}° nota do {i + 1}° aluno.");
                    if (Convert.ToDouble(auxnotas) > 10 || Convert.ToDouble(auxnotas) < 0)
                    {
                        MessageBox.Show("A nota deve estar entre 0 e 10!");
                        j--;//retorne uma casa
                    }
                    else
                    {
                        soma = soma + (Convert.ToDouble(auxnotas));
                    }

                }
                media = soma / 3;
                MessageBox.Show($"Aluno: {i+1}  media: " + Convert.ToString(media));
                soma = 0;
                media = 0;
            }
          
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            frm4 obj1 = new frm4();
            obj1.Show();
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            frm5 obj1 = new frm5();
            obj1.Show();
        }
    }
}
