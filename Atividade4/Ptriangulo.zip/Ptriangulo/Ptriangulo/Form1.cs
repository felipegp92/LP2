﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double ladoa, ladob, ladoc, triangulo;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtB_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtB.Text, out ladob)) ;
        }

        private void txtC_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtC.Text, out ladoc)) ;
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
            txtTriangulo.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if ((ladoa < ladob + ladoc) && (ladoa > Math.Abs(ladob - ladoc) && 
                (ladob < ladoa + ladoc) && (ladob > Math.Abs(ladoa - ladoc) && 
                (ladoc < ladoa + ladob) && (ladoc > Math.Abs(ladoa - ladob)))))
            {
                if ( ladoa == ladob && ladob == ladoc )
                {
                    txtTriangulo.Text = "Equilatero";
                }
                if ( ladoa == ladob || ladoa == ladoc || ladob == ladoc )
                {
                    txtTriangulo.Text = "Isósceles";
                }
                if ( ladoa != ladob && ladoa != ladoc && ladob != ladoc )
                {
                    txtTriangulo.Text = "Escaleno";
                }
            }
            else
            {
                MessageBox.Show("Os valores nao formam um triangulo");
            }
        }

        private void txtA_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtA.Text, out ladoa)) ;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
