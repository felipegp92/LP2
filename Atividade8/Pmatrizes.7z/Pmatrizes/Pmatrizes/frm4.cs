﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class frm4 : Form
    {
        public frm4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[10];
            string nome = "";
            int[] tamanho = new int[30];

            for (int i = 0; i < vetor.Length; i++)
            {
                nome = Interaction.InputBox($"Digite o {i + 1}º nome", "Entrada de Dados");  //interaction para usar a biblioteca do visual basic

                if (nome == "")
                {
                    break;
                }

                tamanho[i] = nome.Replace(" ", "").Length;

                listBox1.Items.Add($"o nome: {nome} tem {tamanho[i]} caracteres \n");

            }
        }
    }
}
