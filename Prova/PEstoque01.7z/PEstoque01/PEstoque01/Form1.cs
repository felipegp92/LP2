﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PEstoque01
{
    public partial class Form1 : Form
    {
                public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int[,] produtos = new int[2,4];
            string auxprodutos;
            int somaProduto = 0;
            int produtoTotal = 0;

            for (int i = 0; i < 2; i++) // i = produtos
            {
                for (int j = 0; j < 4; j++) // j = semanas do mês
                {
                    auxprodutos = Interaction.InputBox($"Entrada do Produto {i + 1}:  Semana {j + 1}: ");
                    if (auxprodutos == "")
                    {
                        break;
                    }
                    if (Convert.ToInt32(auxprodutos) > 0)
                    {
                        listBox1.Items.Add($"Entrada do Produto {i + 1}:  Semana {j + 1} - {auxprodutos}\n");
                        somaProduto = somaProduto + Convert.ToInt16(auxprodutos);
                    }
                    else 
                    { 
                        j--;
                    }
                }
                listBox1.Items.Add($">> Total Entrada do Produto {i+1} - {somaProduto}\n");
                listBox1.Items.Add($"----------------------------------------\n");
                produtoTotal = produtoTotal + somaProduto;
                
                somaProduto = 0;
            }
            listBox1.Items.Add($">> Total Geral Entradas:             {produtoTotal}\n");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void listBox1_Validated(object sender, EventArgs e)
        {
            
        }
    }
}
